user_pref("browser.cache.disk.parent_directory", "C:\\Users\\Erica\\Downloads\\Basilisk Portable with Flash\\User\\Basilisk\\Profiles\\Default");
user_pref("browser.download.lastDir", "C:\\Users\\Erica\\Downloads\\Basilisk Portable with Flash\\Downloads");
user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.taskbar.lists.enabled", false);
